--
-- Volcado de datos para la tabla `distribuidores`
--

INSERT INTO `distribuidores` (`IdDistribuidor`, `NombreCompania`, `Telefono`) VALUES
(1, 'Speedy Express', '(503) 555-9831'),
(2, 'United Package', '(503) 555-3199'),
(3, 'Federal Shipping', '(503) 555-9931');
